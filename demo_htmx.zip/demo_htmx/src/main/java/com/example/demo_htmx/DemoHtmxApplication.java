package com.example.demo_htmx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoHtmxApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoHtmxApplication.class, args);
	}

}
