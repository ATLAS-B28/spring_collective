package com.example.demo_htmx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoHtmxApplicationTests {

	@Test
	void contextLoads() {
	}

}
