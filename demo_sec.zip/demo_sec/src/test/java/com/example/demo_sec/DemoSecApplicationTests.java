package com.example.demo_sec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSecApplicationTests {

	@Test
	void contextLoads() {
	}

}
