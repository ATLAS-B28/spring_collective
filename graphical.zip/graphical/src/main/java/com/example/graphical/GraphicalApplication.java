package com.example.graphical;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphicalApplication {

	public static void main(String[] args) {
		SpringApplication.run(GraphicalApplication.class, args);
	}

}
