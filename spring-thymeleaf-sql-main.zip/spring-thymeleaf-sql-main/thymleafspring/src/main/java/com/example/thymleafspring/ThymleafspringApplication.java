package com.example.thymleafspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymleafspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymleafspringApplication.class, args);
	}

}
