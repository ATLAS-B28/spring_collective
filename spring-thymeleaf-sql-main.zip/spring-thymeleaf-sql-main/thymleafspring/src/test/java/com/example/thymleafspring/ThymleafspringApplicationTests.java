package com.example.thymleafspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymleafspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
