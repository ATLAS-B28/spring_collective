package com.example.demo_web_socket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoWebSocketApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoWebSocketApplication.class, args);
	}

}
