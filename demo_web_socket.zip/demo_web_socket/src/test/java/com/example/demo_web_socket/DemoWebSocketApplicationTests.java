package com.example.demo_web_socket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoWebSocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
