package com.example.demo_employee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
