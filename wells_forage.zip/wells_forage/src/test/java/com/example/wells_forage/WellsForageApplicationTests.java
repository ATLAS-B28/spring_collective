package com.example.wells_forage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WellsForageApplicationTests {

	@Test
	void contextLoads() {
	}

}
