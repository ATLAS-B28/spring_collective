package com.example.demo_chat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
