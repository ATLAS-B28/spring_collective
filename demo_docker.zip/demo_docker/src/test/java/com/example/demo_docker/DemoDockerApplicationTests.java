package com.example.demo_docker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
